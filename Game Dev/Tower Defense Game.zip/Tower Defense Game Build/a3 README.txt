-----------------------------------------------------------------------------------
Assignment 3: Tower Defense-Like Game README
-----------------------------------------------------------------------------------
Student Name: Sebastian Klemkosky
Student abc123: lmo120


-----------------------------------------------------------------------------------
Links to Project (if you used Google Drive, OneDrive, or Dropbox for submission)
-----------------------------------------------------------------------------------
Please provide your Google Drive, OneDrive, or Dropbox link here if you used it for 
your submission, otherwise you may skip this section if you just submitted your
assignment on Blackboard (zipped up). (Make sure the link does not expire and the 
link permissions allow us to download, otherwise you may receive a grade of 0 on 
your assignment submission if we cannot download it.)

Place this Link to Your Unity Project Here:
https://drive.google.com/file/d/1fXwFBNjCgwoiFU2biE9BamwLA3XojuWK/view?usp=sharing


-----------------------------------------------------------------------------------
Version of Unity You Used for Your Game
-----------------------------------------------------------------------------------
Please write down the version of Unity you used when making your game here (e.g.
2019.4, 2020.1, 2020.2, etc...):

2020.1.3f1
-----------------------------------------------------------------------------------
Which Operating System You Made Your Game In
-----------------------------------------------------------------------------------
Please write down which operating system the computer you used while you worked in 
Unity has.  Are you using a MS Windows PC, or a Mac, or a Linux computer, etc.?  
(This matters because when you build the game, some of the files Unity produces 
will be different and your grader needs to know this in order to properly open 
your project):

Windows PC
-----------------------------------------------------------------------------------
Game Controls 
-----------------------------------------------------------------------------------
Please explain what your buttons do. (You do not have to use all of these buttons.
If you use buttons other than these, please mention them to let us know.)

Mouse Movement: 
		
Mouse Click: Click the Tower buttons to place towers. Also click on those towers to upgrade if you have the funds
W or ↑: 
A or ←: 
D or →: 
S or ↓: 
Spacebar: 
Esc: Pause Menu


-----------------------------------------------------------------------------------
Assets Downloaded for Game
-----------------------------------------------------------------------------------
Any assets that you downloaded and used from the Asset Store needs to be documented.
Please provide any links to these assets from the Asset Store you downloaded here:

https://assetstore.unity.com/packages/3d/vegetation/trees/conifers-botd-142076
https://assetstore.unity.com/packages/3d/characters/robots/enemy-turrets-27858
https://assetstore.unity.com/packages/3d/characters/robots/scifi-enemies-and-vehicles-15159
https://assetstore.unity.com/packages/vfx/particles/fire-explosions/explosive-realistic-vfx-texture-free-34541
https://assetstore.unity.com/packages/3d/props/weapons/free-sci-fi-gatling-gun-tower-defense-134222


-----------------------------------------------------------------------------------
Instructions for Students
-----------------------------------------------------------------------------------
Please make sure you place all of your written scripts within a folder called 
"Scripts" to make it easier for the professor and/or TA/grader to find your 
written code for grading.

The following sections are divided into each grading criteria for your assignment
submission. For each section where you must briefly describe something, a sentence
or two is all that is needed just to get your point across. If you did not
implement a particular feature (grading criteria), such as the extra credits, then 
simply mention "Did not do".


-----------------------------------------------------------------------------------
1. Point and Click Interface for Placing/Upgrading Towers (15 pts)
-----------------------------------------------------------------------------------
Briefly describe how you implemented your point-and-click interface for placing/
upgrading towers. e.g. Which script did you write that implements this? (Mention 
whether this script was attached to any game object and which ones.)

I followed what was done in class. The Towers could be instantiated on Buttons using Unity UI.
The Script that does this is call Tower Generator. You get a random Tower when you click on the button. This was attached to those Buttons. The Towers could be upgraded if you click on them.
This upgrade was done in the Tower Script. Each Upgrade is a Tier and as you click on the Towers it will be a higher Tier.


-----------------------------------------------------------------------------------
2. 3 Types of Towers with Different Statistics (20 pts)
-----------------------------------------------------------------------------------
Mention your tower types here. (Minimum of 3) Mention which folder in your 
project that you have placed these prefabs so that we can view them.

Name of Folder with Tower Prefabs: Assets/Prefabs
Tower 1: Tower1Gun - Shoots fast but less damage 
Tower 2: Tower2Gun - Shoots at a medium rate with medium damage
Tower 3: Tower3Gun - Shoots Slow with high damage


-----------------------------------------------------------------------------------
3. Towers Should be Upgradable 3 Times Based on Use of Points/Coins/Magic (20 pts)
-----------------------------------------------------------------------------------
Briefly describe how you implemented your towers being upgradable 3 times. e.g. 
Which script did you write that implements this? (Mention whether this script was 
attached to any game object and which ones.)

The Tower Script handles the Upgrading of all the Towers. All Towers have this script. When a Tower is upgraded some values are changes which makes the Tower better.
When A Enemy is killed the player is awarded Coins. If the player has enough keys when they click on a Tower it Upgrades or if they click on a Button a new tower is 
instantiated.

There is a bug, which I was unable to fix. The first tower you create can go through the upgrade process normallly. Any other tower that is made skips some Upgrade
Tiers until The Tower gets fully upgraded on 1 Click. Technically there are 3 Upgrades for the Towers but this bug eventually makes it so there is only 1. 

-----------------------------------------------------------------------------------
4. 3 Types of Enemies with Different Stats (20 pts)
-----------------------------------------------------------------------------------
Mention your enemy types here. (Minimum of 3) Mention which folder in your 
project that you have placed these prefabs so that we can view them.

Name of Folder with Enemy Prefabs: Assets/Prefabs
Enemy 1: TankEnemyCraft - Slower but has more health
Enemy 2: EnemyBug - Normal Enemy
Enemy 3: FastEnemyDrone - Quick Enemy with less health

There is a bug for the Drone and Bug Enemy. I think this has to do with Animations causing the issue but I was unable to completely fix this. Also this bug doesn't
seem to appear in the Unity Editor itself but when I build and run the game it is apparent when it happens. These enemies sometimes get stuck and stop moving for a bit.
From I seen they eventually get unstuck and continue moving onward. 


-----------------------------------------------------------------------------------
5. Target Position That Decreases "Life" if Enemies Cross (10 pts)
-----------------------------------------------------------------------------------
Briefly describe how you implemented a target position that decreases life if
enemies cross this. e.g. Which script did you write that implements this? (Mention 
whether this script was attached to any game object and which ones.)

Please give the x, y, and z coordinate of this target position where enemies will
drain your life if they cross (for the first level at least): (_, _, _)

All the Enemies have a script where when they get to the end they get destroyed and the player loses health.
When they player is out of health the game ends. There isn't a specific end point for this rather the Enemies start on the left side of the map
and moves to the right where they get destroyed if they get to the end. The path for the enemies will be random everytime you play the game.



-----------------------------------------------------------------------------------
6. Nice Textured Assets (10 pts)
-----------------------------------------------------------------------------------
It is up to you which assets you would like to add to your game.  Please just
mention a few that you used here:

https://assetstore.unity.com/packages/3d/vegetation/trees/conifers-botd-142076
https://assetstore.unity.com/packages/3d/characters/robots/enemy-turrets-27858
https://assetstore.unity.com/packages/3d/characters/robots/scifi-enemies-and-vehicles-15159

Enemies, Trees, Towers



-----------------------------------------------------------------------------------
7. Advancing Levels When All Enemies are "Dead" (10 pts)
-----------------------------------------------------------------------------------
Briefly describe how you implemented your character advancing to the next level
after all of the enemies are "dead". e.g. Which script did you write that 
implements this? (Mention whether this script was attached to any game object and
which ones.)


Briefly describe what pops up when you advance to the next level. If there is a 
script associated with this, what is it and what game object is it attached to?

In the GameController Script attached to the GameController Object. Text on Screen appears saying "WAVE CLEARED" when the enemies that spawn for the specific wave are killed. More Enemies spawn quickly


Briefly describe how each level has more or stronger enemies. e.g. Which script did
you write that implements this? (Mention whether this script was attached to any
game object and which ones.)

There is a Enemy Container Game Object which holds all the Enemies. The Script attached to this object called Enemy Spawner takes care of spawning enemies.
Each Wave has more enemies then the last making it more difficult for the player.

-----------------------------------------------------------------------------------
8. Audio FX and Music (10 pts)
-----------------------------------------------------------------------------------
-Audio-
You are free to use whatever 3D audio FX sounds you like. You can use as many sounds 
as you would like for things like your towers shooting, enemies shooting/attacking,
enemies dying, etc. Please list the sounds you used in your game here:

         Audio FX Sound Effect       |      When Audio FX is Used
1) 	laser1.wav	             | 	Tower1Gun shooting
2) 	laser2.wave		     |  Tower2Gun shooting
3) 	laser3.wav		     |  Tower3Gun shooting
4) 				     |


-Music-
You are free to add whatever music you wish to your game. Please list the name of 
the songs used and where they appear in your game. If you downloaded them from a 
website, please document the source. If you used more than 2 songs, please list 
them and their source as well.

1) Music Song Name: A Few Jumps Away - By Arthur Vyncke
   Where This Appears in Your Game: In game it starts to play
   Music Song Source: https://www.free-stock-music.com/arthur-vyncke-a-few-jumps-away.html

2) Music Song Name:
   Where This Appears in Your Game:
   Music Song Source:


-----------------------------------------------------------------------------------
9. Terrain With Nice Trees and Stuff (10 pts)
-----------------------------------------------------------------------------------
Mention which folder you have placed your textures for your terrain here:

Mention which folder you have placed your tree prefabs that you used:

Assets/Terrain

If you used, any other stuff, please mention the folder you placed these prefabs
here:

Assets/Conifers[BOTD]

-----------------------------------------------------------------------------------
10. Particle Effects (10 pts)
-----------------------------------------------------------------------------------
Mention which folder you have placed your particle effects here: Assets/ExplosiveRealFree
								 Assets/Prefabs

You are free to add whatever particle effects you want for your game, such as
explosions or spells, but please list them below:

          Particle Effect       		 
1)       Enemy Death Explosion				   
2)  
3) 
4)                               


-----------------------------------------------------------------------------------
11. Game Should Run With Reasonable Performance (40-60 fps) (15 pts)
-----------------------------------------------------------------------------------
Your game should be playable in 40 to 60 frames per second. Please make sure that 
you test your game with this frame rate before submitting your assignment.


-----------------------------------------------------------------------------------
*Extra Credit* Fully Featured HUD (5 pts)
-----------------------------------------------------------------------------------
Please fill in the following list for your HUD features and their locations within
the HUD (such as top-left, bottom-right, top-center, bottom-center, etc.):

       		 HUD Feature        		  |      Location within HUD
1) Current Level       				  |      Wave Number located on the left
2) Number of Enemies Left to Kill in Current Wave | 	 Enemies located on the left
3) Icons for Current Points/Coins/Gold etc.       |	 Money/Coin located on the right
4) Icon for "Life"                                |	 Health Bar with heart located on the right

Please mention the scripts that are associated with each of these HUD features.
The GameController object handles all of this. Has the GameController Script attached to it

What is your character's life based on (i.e. hit points, money left, etc.)?
hit points or health

-----------------------------------------------------------------------------------
*Extra Credit* Game Menus, Nice Title Screen, Change/Restart Level (5 pts)
-----------------------------------------------------------------------------------
You are free to add whatever buttons or controls you want for your title screen, 
but you at least must implement some sort of "Play" or "Start" button. You must 
also implement some sort of "Quit" button that quits the game application entirely.
Which script(s) is associated with your Title Screen?
GameController and Menu Scripts

In addition to your title screen menu, what other game menus did you implement 
(such as a pause menu, a game over menu, etc)?
There is pause menu in game

Which script(s) are associated with each of these menus?
GameController and Menu Script are attached to the GameController and MenuController objects

-----------------------------------------------------------------------------------
*Extra Credit* Choose Any Two of the Following for 5pts Each (10 pts)
-----------------------------------------------------------------------------------
----------First-Person Mode----------
Explain how to the player is able to do this. (i.e. Do we need to click something 
or press a button on the keyboard, etc.?)


Which script(s) is associated with this?



----------Pathfinding AI for Enemies----------
Did you use a NavMesh:
(Answer Yes or No): No

If not, then how did you accomplish this?
A Waypoint system for enemies like what was done in class. Waypoints were created for the enemies to follow
This was done in the Path Generator Script


----------Animation for Characters----------
Briefly describe how you implemented your animation for the characters within the 
game. e.g. Which script did you write that implements this? (Mention whether this 
script was attached to any game object and which ones.)

The Drone and Bug enemy has a simple walking/ forward animation. An Animation controller is in the Animations folder. 


-----------------------------------------------------------------------------------
Any Notes or Things the Professor or TA/Grader Should Be Aware Of
-----------------------------------------------------------------------------------
If there are any other concerns that you have about your submission or any known
bugs/glitches in your game that could potentially come up, please explain them here:

Bugs with Tower Upgrades and Enemies. See those sections for more detail.

